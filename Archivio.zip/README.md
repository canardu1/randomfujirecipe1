# randomfujirecipe1

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/canardu1/randomfujirecipe1)